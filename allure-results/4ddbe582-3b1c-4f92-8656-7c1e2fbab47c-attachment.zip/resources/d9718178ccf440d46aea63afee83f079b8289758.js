
      importScripts("blob:https://localhost:8080/ac7e9cc4-9ba5-421d-81fe-d817a60185af");
      CesiumWorkers["createVerticesFromHeightmap"]();
    