
      importScripts("blob:https://localhost:8080/7b7333cd-a18d-4607-8999-d0d8140214d0");
      CesiumWorkers["createVerticesFromHeightmap"]();
    