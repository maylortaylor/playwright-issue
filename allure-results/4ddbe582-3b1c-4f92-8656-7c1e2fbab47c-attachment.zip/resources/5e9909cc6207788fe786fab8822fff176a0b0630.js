
      importScripts("blob:https://localhost:8080/5ffe2c51-4ddd-429e-b4f5-4d54989f0ef9");
      CesiumWorkers["createVerticesFromHeightmap"]();
    