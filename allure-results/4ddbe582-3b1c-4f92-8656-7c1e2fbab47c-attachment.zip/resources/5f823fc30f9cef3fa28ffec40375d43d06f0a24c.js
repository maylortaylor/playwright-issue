
      importScripts("blob:https://localhost:8080/bab482f4-1fe7-45ca-a4f7-6db63f55dc96");
      CesiumWorkers["transferTypedArrayTest"]();
    