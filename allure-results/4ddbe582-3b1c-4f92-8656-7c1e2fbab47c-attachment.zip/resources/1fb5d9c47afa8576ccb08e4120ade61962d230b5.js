
      importScripts("blob:https://localhost:8080/cb96efb8-4c5b-4bfe-a825-2f3b5c9b68d9");
      CesiumWorkers["createVerticesFromHeightmap"]();
    