
      importScripts("blob:https://localhost:8080/ee5060ed-0340-4575-8820-5645fb6834e6");
      CesiumWorkers["createVerticesFromHeightmap"]();
    