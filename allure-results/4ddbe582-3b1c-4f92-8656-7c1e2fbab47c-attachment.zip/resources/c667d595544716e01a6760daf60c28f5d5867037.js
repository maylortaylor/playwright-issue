
      importScripts("blob:https://localhost:8080/ac5e0614-3ce2-4bd9-bef2-bc6d2d0895e3");
      CesiumWorkers["transferTypedArrayTest"]();
    