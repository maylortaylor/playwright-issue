
      importScripts("blob:https://localhost:8080/12855eec-2b95-4e74-b874-7d9a2adb0c8d");
      CesiumWorkers["transferTypedArrayTest"]();
    