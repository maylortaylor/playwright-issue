
      importScripts("blob:https://localhost:8080/5a3a45b4-7ece-432d-af50-57ae19b80082");
      CesiumWorkers["transferTypedArrayTest"]();
    