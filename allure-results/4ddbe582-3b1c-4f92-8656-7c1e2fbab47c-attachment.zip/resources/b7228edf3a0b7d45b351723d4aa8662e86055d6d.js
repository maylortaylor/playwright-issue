
      importScripts("blob:https://localhost:8080/8fb263ac-a232-4879-b070-1997e1da4cf2");
      CesiumWorkers["createVerticesFromHeightmap"]();
    