
      importScripts("blob:https://localhost:8080/3abab095-6e74-4d55-b10b-b30cca152ffa");
      CesiumWorkers["transferTypedArrayTest"]();
    