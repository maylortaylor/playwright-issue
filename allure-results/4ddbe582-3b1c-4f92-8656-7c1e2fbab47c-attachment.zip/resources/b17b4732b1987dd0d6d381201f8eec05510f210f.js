
      importScripts("blob:https://localhost:8080/1952c01e-9d92-4ca6-88ff-4b752919d374");
      CesiumWorkers["transferTypedArrayTest"]();
    