
      importScripts("blob:https://localhost:8080/79d735aa-c182-419c-85fb-5901936b96d3");
      CesiumWorkers["createVerticesFromHeightmap"]();
    