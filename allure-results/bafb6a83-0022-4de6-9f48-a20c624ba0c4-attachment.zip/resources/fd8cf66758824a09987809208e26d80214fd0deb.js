
      importScripts("blob:https://localhost:8080/9a06f646-892e-4f74-9c7b-e758d13c39b0");
      CesiumWorkers["transferTypedArrayTest"]();
    