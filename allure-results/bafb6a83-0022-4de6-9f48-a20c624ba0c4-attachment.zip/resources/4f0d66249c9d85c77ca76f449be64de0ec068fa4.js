
      importScripts("blob:https://localhost:8080/e5446f05-7c4d-4c21-90db-b93b2442c780");
      CesiumWorkers["createVerticesFromHeightmap"]();
    