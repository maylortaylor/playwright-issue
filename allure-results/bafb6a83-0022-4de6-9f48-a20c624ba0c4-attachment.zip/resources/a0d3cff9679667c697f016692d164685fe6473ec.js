
      importScripts("blob:https://localhost:8080/1c8e48d5-db21-4c17-a178-0d61191e97c4");
      CesiumWorkers["createVerticesFromHeightmap"]();
    