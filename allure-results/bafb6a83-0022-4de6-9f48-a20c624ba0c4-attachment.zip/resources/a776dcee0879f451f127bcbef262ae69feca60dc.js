
      importScripts("blob:https://localhost:8080/9b19f0b4-bf5e-4dec-acc9-99763e19df99");
      CesiumWorkers["transferTypedArrayTest"]();
    