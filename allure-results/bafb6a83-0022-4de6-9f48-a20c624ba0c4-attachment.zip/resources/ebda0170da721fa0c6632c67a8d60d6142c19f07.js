
      importScripts("blob:https://localhost:8080/a37ae432-3996-43ec-aa1f-971621b12ce9");
      CesiumWorkers["transferTypedArrayTest"]();
    