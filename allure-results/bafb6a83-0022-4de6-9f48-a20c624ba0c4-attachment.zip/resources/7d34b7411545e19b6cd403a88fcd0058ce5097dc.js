
      importScripts("blob:https://localhost:8080/f1ed6869-88b3-4b69-a1d2-78f2139a5a74");
      CesiumWorkers["createVerticesFromHeightmap"]();
    