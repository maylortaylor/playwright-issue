
      importScripts("blob:https://localhost:8080/b7342ca8-12de-41a0-8835-a20c0f747871");
      CesiumWorkers["createVerticesFromHeightmap"]();
    