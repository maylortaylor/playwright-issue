
      importScripts("blob:https://localhost:8080/96aa97d5-f546-427f-8ed2-5c4d845e0dd4");
      CesiumWorkers["transferTypedArrayTest"]();
    