
      importScripts("blob:https://localhost:8080/019161c1-f82b-43cc-8785-468e08f1e2e8");
      CesiumWorkers["transferTypedArrayTest"]();
    