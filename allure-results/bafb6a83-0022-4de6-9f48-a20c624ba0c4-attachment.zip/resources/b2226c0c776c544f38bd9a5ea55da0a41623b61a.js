
      importScripts("blob:https://localhost:8080/af3aa6ef-a062-4357-93f2-1d96f45a3401");
      CesiumWorkers["createVerticesFromHeightmap"]();
    