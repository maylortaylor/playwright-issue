
      importScripts("blob:https://localhost:8080/a15e196d-dce9-4a1f-868d-f607addb958a");
      CesiumWorkers["createVerticesFromHeightmap"]();
    