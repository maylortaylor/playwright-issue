
      importScripts("blob:https://localhost:8080/fb5247ec-ad17-47f8-a135-4dfed5871efb");
      CesiumWorkers["transferTypedArrayTest"]();
    