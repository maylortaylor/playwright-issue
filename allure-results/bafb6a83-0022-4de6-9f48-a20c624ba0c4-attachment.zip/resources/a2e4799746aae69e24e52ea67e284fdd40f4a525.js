
      importScripts("blob:https://localhost:8080/745957b0-e01e-41dd-bee0-b0b702848194");
      CesiumWorkers["createVerticesFromHeightmap"]();
    