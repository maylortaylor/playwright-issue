
      importScripts("blob:https://localhost:8080/70052d66-9ccf-4349-85b4-635e84c62ea4");
      CesiumWorkers["transferTypedArrayTest"]();
    