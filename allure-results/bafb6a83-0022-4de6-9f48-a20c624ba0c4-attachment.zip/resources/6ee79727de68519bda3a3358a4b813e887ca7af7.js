
      importScripts("blob:https://localhost:8080/271731bf-4877-4c06-b641-c55dd898f938");
      CesiumWorkers["transferTypedArrayTest"]();
    