
      importScripts("blob:https://localhost:8080/e6e35cee-4fe2-4bb0-81d5-aa9bbc8d7227");
      CesiumWorkers["transferTypedArrayTest"]();
    