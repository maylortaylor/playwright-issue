
      importScripts("blob:https://localhost:8080/9e462fa9-aa51-45e3-b27f-1a7c62134e2e");
      CesiumWorkers["createVerticesFromHeightmap"]();
    