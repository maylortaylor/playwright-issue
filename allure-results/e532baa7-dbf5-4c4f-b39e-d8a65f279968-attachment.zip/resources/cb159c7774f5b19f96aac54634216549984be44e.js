
      importScripts("blob:https://localhost:8080/45670a9f-f2e3-4abd-86b3-9375b1b111da");
      CesiumWorkers["createVerticesFromHeightmap"]();
    