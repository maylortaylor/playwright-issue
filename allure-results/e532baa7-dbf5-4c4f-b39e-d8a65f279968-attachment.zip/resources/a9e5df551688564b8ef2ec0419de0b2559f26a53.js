
      importScripts("blob:https://localhost:8080/017c9d16-20c2-4da2-9234-dacc8a18da80");
      CesiumWorkers["createVerticesFromHeightmap"]();
    