
      importScripts("blob:https://localhost:8080/dc2eec4b-9484-4baa-b591-f94061d91c57");
      CesiumWorkers["transferTypedArrayTest"]();
    