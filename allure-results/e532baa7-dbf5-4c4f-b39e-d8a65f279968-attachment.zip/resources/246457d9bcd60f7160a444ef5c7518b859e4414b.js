
      importScripts("blob:https://localhost:8080/c5dbcd01-1071-428e-b742-85116309845d");
      CesiumWorkers["createVerticesFromHeightmap"]();
    