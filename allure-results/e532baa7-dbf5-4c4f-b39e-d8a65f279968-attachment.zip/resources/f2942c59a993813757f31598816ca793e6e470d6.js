
      importScripts("blob:https://localhost:8080/6fe3c529-7577-45f6-8902-5179cf852c50");
      CesiumWorkers["transferTypedArrayTest"]();
    