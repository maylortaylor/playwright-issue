
      importScripts("blob:https://localhost:8080/570008b4-425e-4d99-a9a8-ccf55584dace");
      CesiumWorkers["createVerticesFromHeightmap"]();
    