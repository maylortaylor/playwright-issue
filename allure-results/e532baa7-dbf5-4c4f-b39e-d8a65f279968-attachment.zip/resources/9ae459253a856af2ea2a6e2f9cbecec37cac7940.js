
      importScripts("blob:https://localhost:8080/27d4c6ff-2d11-4da6-91e3-e3ad06064477");
      CesiumWorkers["transferTypedArrayTest"]();
    