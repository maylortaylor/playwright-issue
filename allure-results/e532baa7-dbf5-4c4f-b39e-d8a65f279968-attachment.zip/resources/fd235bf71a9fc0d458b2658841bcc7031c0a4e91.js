
      importScripts("blob:https://localhost:8080/4e0e9c8b-192b-4e12-a556-8630b0a1750b");
      CesiumWorkers["transferTypedArrayTest"]();
    