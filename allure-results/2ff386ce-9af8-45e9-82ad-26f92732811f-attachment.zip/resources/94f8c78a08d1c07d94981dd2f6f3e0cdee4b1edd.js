
      importScripts("blob:https://localhost:8080/280c64ab-d0dc-43cc-92b0-0b444c7383ca");
      CesiumWorkers["transferTypedArrayTest"]();
    