
      importScripts("blob:https://localhost:8080/d83892ea-bf7a-46af-863a-befe62c9742b");
      CesiumWorkers["createVerticesFromHeightmap"]();
    