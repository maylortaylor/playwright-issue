
      importScripts("blob:https://localhost:8080/32eb3d1b-4fb7-4095-8e3c-d6aef53f5d2a");
      CesiumWorkers["createVerticesFromHeightmap"]();
    