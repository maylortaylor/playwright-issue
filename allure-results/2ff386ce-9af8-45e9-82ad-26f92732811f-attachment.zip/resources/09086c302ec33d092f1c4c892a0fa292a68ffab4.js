
      importScripts("blob:https://localhost:8080/c33772a7-78d5-4035-9ca5-4e99d7ede261");
      CesiumWorkers["createVerticesFromHeightmap"]();
    