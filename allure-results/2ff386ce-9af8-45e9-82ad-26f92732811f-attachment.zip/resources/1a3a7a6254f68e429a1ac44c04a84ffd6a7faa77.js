
      importScripts("blob:https://localhost:8080/5238480f-339a-4e2f-bf49-f9cadc425035");
      CesiumWorkers["transferTypedArrayTest"]();
    