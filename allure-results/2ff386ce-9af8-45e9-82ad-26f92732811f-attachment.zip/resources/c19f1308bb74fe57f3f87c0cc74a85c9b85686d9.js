
      importScripts("blob:https://localhost:8080/90c17feb-60fb-46e6-8177-935dcf7d0a71");
      CesiumWorkers["transferTypedArrayTest"]();
    