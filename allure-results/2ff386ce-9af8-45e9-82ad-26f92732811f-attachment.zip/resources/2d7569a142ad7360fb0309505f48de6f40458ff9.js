
      importScripts("blob:https://localhost:8080/8d460c91-a0da-4500-baed-41b4e3894537");
      CesiumWorkers["createVerticesFromHeightmap"]();
    