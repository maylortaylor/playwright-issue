
      importScripts("blob:https://localhost:8080/d621e2bc-0efd-4cdf-806e-a3087009b9f8");
      CesiumWorkers["createVerticesFromHeightmap"]();
    