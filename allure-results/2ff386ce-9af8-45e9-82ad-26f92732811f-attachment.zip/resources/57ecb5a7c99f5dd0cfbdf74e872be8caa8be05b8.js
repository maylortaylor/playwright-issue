
      importScripts("blob:https://localhost:8080/a4243b8d-7e97-4788-99ec-9954542aa6c9");
      CesiumWorkers["transferTypedArrayTest"]();
    