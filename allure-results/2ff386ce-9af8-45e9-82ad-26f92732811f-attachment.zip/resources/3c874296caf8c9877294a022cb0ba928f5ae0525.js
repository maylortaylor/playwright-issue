
      importScripts("blob:https://localhost:8080/12894c3b-8109-43d6-b196-da42ddbeb1c2");
      CesiumWorkers["transferTypedArrayTest"]();
    