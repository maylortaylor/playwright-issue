
      importScripts("blob:https://localhost:8080/2c586228-8c7c-4f10-8c48-916fe9c6eeab");
      CesiumWorkers["createVerticesFromHeightmap"]();
    