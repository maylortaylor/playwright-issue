
      importScripts("blob:https://localhost:8080/5125fb5f-b74b-4283-8578-a63acccec3a4");
      CesiumWorkers["transferTypedArrayTest"]();
    