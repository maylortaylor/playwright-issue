
      importScripts("blob:https://localhost:8080/c5fbfc58-58db-47ee-add9-0bde5ec118be");
      CesiumWorkers["createVerticesFromHeightmap"]();
    