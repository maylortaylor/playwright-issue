
      importScripts("blob:https://localhost:8080/8697d8d6-45d5-49a9-950c-790f2acf4fcb");
      CesiumWorkers["transferTypedArrayTest"]();
    