
      importScripts("blob:https://localhost:8080/c55bd771-0858-4d07-9a41-b22596ab7b88");
      CesiumWorkers["createVerticesFromHeightmap"]();
    