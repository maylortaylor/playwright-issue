
      importScripts("blob:https://localhost:8080/31c766e8-01db-4f22-a7cf-01f59893f699");
      CesiumWorkers["transferTypedArrayTest"]();
    