
      importScripts("blob:https://a22040195163f493bb3eff32c1f8a587-572051981.us-gov-east-1.elb.amazonaws.com/77b3c6d3-f351-4476-8db8-59d58354ce02");
      CesiumWorkers["transferTypedArrayTest"]();
    