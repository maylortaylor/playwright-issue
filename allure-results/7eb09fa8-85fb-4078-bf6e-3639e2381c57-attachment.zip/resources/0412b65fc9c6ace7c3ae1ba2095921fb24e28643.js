
      importScripts("blob:https://a22040195163f493bb3eff32c1f8a587-572051981.us-gov-east-1.elb.amazonaws.com/97a6a84c-fc5d-46ec-ad3a-275b0238d49f");
      CesiumWorkers["createVerticesFromHeightmap"]();
    