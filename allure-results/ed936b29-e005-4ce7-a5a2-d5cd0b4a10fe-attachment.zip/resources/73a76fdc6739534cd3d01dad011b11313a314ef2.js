
      importScripts("blob:https://localhost:8080/54c7456c-14d0-4c97-b2d6-7ea385beef6b");
      CesiumWorkers["createVerticesFromHeightmap"]();
    