
      importScripts("blob:https://localhost:8080/a361e67a-5f80-4783-8b98-1e6e85bc6b72");
      CesiumWorkers["transferTypedArrayTest"]();
    