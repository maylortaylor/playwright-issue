
      importScripts("blob:https://localhost:8080/40313926-20a6-4aee-8c29-353069edb41d");
      CesiumWorkers["createVerticesFromHeightmap"]();
    