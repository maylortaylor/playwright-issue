
      importScripts("blob:https://localhost:8080/42efc1a6-a8fa-427e-b0a2-11b1d53319af");
      CesiumWorkers["transferTypedArrayTest"]();
    