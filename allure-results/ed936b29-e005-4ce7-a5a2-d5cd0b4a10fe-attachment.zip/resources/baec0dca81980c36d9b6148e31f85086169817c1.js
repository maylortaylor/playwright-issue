
      importScripts("blob:https://localhost:8080/83a92aa4-81ce-4433-a15a-2a678e5b5b8e");
      CesiumWorkers["transferTypedArrayTest"]();
    