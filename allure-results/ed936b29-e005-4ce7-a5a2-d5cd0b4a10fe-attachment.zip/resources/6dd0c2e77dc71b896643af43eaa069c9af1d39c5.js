
      importScripts("blob:https://localhost:8080/1545a1c7-a9d1-402b-a8cb-6a35c346549c");
      CesiumWorkers["createVerticesFromHeightmap"]();
    