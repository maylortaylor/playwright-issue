
      importScripts("blob:https://localhost:8080/e34ac62e-21aa-491c-a20f-b08f67a120c4");
      CesiumWorkers["transferTypedArrayTest"]();
    