
      importScripts("blob:https://localhost:8080/a72f769f-044f-44cc-865d-69f58cce0908");
      CesiumWorkers["createVerticesFromHeightmap"]();
    