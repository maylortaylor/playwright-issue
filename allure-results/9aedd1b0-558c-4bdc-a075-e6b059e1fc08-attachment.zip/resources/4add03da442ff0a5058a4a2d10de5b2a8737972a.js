
      importScripts("blob:https://localhost:8080/8e5c097f-f449-4b0e-a591-042f5774702a");
      CesiumWorkers["transferTypedArrayTest"]();
    