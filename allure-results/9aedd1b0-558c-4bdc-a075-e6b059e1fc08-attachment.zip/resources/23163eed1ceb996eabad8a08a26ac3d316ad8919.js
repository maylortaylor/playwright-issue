
      importScripts("blob:https://localhost:8080/a9370fc1-f94b-448e-98f8-a3d71431a314");
      CesiumWorkers["createVerticesFromHeightmap"]();
    