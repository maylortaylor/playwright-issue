
      importScripts("blob:https://localhost:8080/bd2f3005-3368-4771-9186-a1fa57b3eb9a");
      CesiumWorkers["createVerticesFromHeightmap"]();
    