
      importScripts("blob:https://localhost:8080/f5837b00-eb45-4e77-80a0-5b197df6f66d");
      CesiumWorkers["transferTypedArrayTest"]();
    