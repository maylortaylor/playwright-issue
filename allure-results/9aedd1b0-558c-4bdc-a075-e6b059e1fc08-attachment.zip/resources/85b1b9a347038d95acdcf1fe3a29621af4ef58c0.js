
      importScripts("blob:https://localhost:8080/98461cf4-ad93-434b-bf83-cb3a34fba091");
      CesiumWorkers["transferTypedArrayTest"]();
    