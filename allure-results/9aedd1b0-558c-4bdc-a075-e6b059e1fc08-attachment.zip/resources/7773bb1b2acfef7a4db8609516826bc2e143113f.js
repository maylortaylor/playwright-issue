
      importScripts("blob:https://localhost:8080/17680322-a98d-4423-9555-4ecdaf557773");
      CesiumWorkers["transferTypedArrayTest"]();
    