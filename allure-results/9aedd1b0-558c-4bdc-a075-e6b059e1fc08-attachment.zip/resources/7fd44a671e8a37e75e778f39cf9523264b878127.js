
      importScripts("blob:https://localhost:8080/b470278a-b240-41bf-8a47-3995a9e45a1c");
      CesiumWorkers["createVerticesFromHeightmap"]();
    