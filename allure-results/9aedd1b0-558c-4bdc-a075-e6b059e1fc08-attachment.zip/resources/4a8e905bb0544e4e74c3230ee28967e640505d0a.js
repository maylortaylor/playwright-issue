
      importScripts("blob:https://localhost:8080/4e0c980c-885c-43fd-abd0-151989923111");
      CesiumWorkers["createVerticesFromHeightmap"]();
    