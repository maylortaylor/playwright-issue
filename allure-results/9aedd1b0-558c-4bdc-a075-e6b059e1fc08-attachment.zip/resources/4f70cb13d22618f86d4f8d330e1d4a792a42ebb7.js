
      importScripts("blob:https://localhost:8080/a8d0dea5-2253-4780-85bb-4c169656c73b");
      CesiumWorkers["createVerticesFromHeightmap"]();
    