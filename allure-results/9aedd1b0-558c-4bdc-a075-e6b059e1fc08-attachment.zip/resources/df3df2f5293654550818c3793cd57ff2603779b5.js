
      importScripts("blob:https://localhost:8080/195d97f5-935e-4152-bcd3-9e7d9035ab61");
      CesiumWorkers["transferTypedArrayTest"]();
    