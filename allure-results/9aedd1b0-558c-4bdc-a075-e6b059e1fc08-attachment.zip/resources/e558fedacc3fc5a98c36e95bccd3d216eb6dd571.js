
      importScripts("blob:https://localhost:8080/e8ec4007-2991-49ba-8e8a-7feaa32d3c12");
      CesiumWorkers["transferTypedArrayTest"]();
    