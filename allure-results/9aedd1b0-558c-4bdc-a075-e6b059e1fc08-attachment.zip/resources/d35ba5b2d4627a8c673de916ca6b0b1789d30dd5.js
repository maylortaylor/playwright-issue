
      importScripts("blob:https://localhost:8080/e79c9ce7-bb4b-472c-8e52-bfef87877aad");
      CesiumWorkers["createVerticesFromHeightmap"]();
    