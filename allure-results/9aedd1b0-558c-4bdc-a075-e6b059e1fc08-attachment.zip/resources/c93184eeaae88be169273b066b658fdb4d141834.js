
      importScripts("blob:https://localhost:8080/6f616b66-45b0-4293-be18-47aa2f82578b");
      CesiumWorkers["createVerticesFromHeightmap"]();
    