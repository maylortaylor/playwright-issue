
      importScripts("blob:https://localhost:8080/d98c3452-772c-42a8-837e-4bf1f8e107eb");
      CesiumWorkers["transferTypedArrayTest"]();
    