
      importScripts("blob:https://localhost:8080/3a05fda2-e819-4eba-92fd-9126acb5fd56");
      CesiumWorkers["transferTypedArrayTest"]();
    