
      importScripts("blob:https://localhost:8080/94c285be-3f1f-4550-babd-1fef13875b55");
      CesiumWorkers["transferTypedArrayTest"]();
    