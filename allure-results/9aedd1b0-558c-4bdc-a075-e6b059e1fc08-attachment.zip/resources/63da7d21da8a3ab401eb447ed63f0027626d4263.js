
      importScripts("blob:https://localhost:8080/69c657ff-6839-44f3-b2e5-117b033ec244");
      CesiumWorkers["createVerticesFromHeightmap"]();
    