
      importScripts("blob:https://localhost:8080/3f37ca25-f4c1-407e-8f05-31a10059b8d3");
      CesiumWorkers["createVerticesFromHeightmap"]();
    