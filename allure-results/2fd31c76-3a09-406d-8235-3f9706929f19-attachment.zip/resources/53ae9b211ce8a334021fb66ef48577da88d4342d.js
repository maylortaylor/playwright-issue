
      importScripts("blob:https://localhost:8080/273e2f46-9c03-473b-90ff-6674086ddcf5");
      CesiumWorkers["createVerticesFromHeightmap"]();
    