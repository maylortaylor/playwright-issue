
      importScripts("blob:https://localhost:8080/71d0eaee-5d77-436e-9e28-76d2b048db48");
      CesiumWorkers["transferTypedArrayTest"]();
    