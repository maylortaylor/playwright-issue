
      importScripts("blob:https://localhost:8080/e654d6f2-62fa-441c-ac8b-23281dc61299");
      CesiumWorkers["createVerticesFromHeightmap"]();
    