
      importScripts("blob:https://localhost:8080/8b02acbe-0217-4602-9d7f-4c1773c9cc93");
      CesiumWorkers["transferTypedArrayTest"]();
    