
      importScripts("blob:https://localhost:8080/95c383e7-68bb-4d38-ab7e-0f96c13b1144");
      CesiumWorkers["transferTypedArrayTest"]();
    