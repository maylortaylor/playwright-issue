
      importScripts("blob:https://localhost:8080/075a9605-f7e3-43ac-9cf2-7ba9eda94c25");
      CesiumWorkers["createVerticesFromHeightmap"]();
    