
      importScripts("blob:https://localhost:8080/8d5f3a73-db4b-4e2e-84a4-1dfd9385537f");
      CesiumWorkers["transferTypedArrayTest"]();
    