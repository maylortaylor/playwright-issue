
      importScripts("blob:https://localhost:8080/58b11199-e059-48c8-afcf-ce52e357fe7f");
      CesiumWorkers["transferTypedArrayTest"]();
    