
      importScripts("blob:https://localhost:8080/a73e009c-c287-451f-9348-28fd204059cf");
      CesiumWorkers["createVerticesFromHeightmap"]();
    