
      importScripts("blob:https://localhost:8080/de77f516-e362-4269-8799-7f9fd5eaa828");
      CesiumWorkers["createVerticesFromHeightmap"]();
    