
      importScripts("blob:https://localhost:8080/496cec64-9b21-4668-a784-1140cf5cc023");
      CesiumWorkers["createVerticesFromHeightmap"]();
    