
      importScripts("blob:https://localhost:8080/d0090c2b-1c62-442c-94a5-fa6e5fa7f6e3");
      CesiumWorkers["transferTypedArrayTest"]();
    