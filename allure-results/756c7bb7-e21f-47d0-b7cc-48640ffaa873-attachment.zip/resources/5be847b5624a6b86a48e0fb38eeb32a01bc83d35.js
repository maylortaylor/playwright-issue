
      importScripts("blob:https://localhost:8080/ffbe9cf4-2c37-4b75-99bc-0cb64f2d3fa7");
      CesiumWorkers["transferTypedArrayTest"]();
    