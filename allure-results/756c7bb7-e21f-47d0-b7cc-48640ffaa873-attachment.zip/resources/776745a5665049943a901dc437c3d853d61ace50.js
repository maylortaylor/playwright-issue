
      importScripts("blob:https://localhost:8080/73220803-51c6-447e-a05f-a286ba14922b");
      CesiumWorkers["createVerticesFromHeightmap"]();
    