
      importScripts("blob:https://localhost:8080/4e415e74-85a3-4c90-8d6e-7fee9201d588");
      CesiumWorkers["createVerticesFromHeightmap"]();
    