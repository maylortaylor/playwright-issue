
      importScripts("blob:https://localhost:8080/f1e9cb2f-b642-4b58-9a6a-4ba5cfec9b78");
      CesiumWorkers["transferTypedArrayTest"]();
    