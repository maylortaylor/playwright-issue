
      importScripts("blob:https://localhost:8080/5eb2a8bc-3fe8-4847-968a-371f60eabd7f");
      CesiumWorkers["createVerticesFromHeightmap"]();
    