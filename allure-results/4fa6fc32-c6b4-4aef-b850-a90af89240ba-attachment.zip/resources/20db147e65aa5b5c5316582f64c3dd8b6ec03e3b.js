
      importScripts("blob:https://localhost:8080/55024c58-3e08-4379-ab88-8f40dba297a2");
      CesiumWorkers["transferTypedArrayTest"]();
    