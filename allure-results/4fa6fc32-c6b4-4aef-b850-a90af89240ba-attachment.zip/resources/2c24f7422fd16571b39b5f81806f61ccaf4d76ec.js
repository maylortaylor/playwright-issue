
      importScripts("blob:https://localhost:8080/756a3332-b8a4-4c7a-9d51-58209e70a738");
      CesiumWorkers["createVerticesFromHeightmap"]();
    