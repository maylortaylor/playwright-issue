
      importScripts("blob:https://localhost:8080/6e6a13d0-43cb-4e2b-adea-97287ebffaf8");
      CesiumWorkers["createVerticesFromHeightmap"]();
    