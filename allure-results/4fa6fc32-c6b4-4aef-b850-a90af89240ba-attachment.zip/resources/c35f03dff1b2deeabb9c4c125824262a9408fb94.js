
      importScripts("blob:https://localhost:8080/737a582e-d8a9-4f02-ad1d-63a2015a515d");
      CesiumWorkers["transferTypedArrayTest"]();
    