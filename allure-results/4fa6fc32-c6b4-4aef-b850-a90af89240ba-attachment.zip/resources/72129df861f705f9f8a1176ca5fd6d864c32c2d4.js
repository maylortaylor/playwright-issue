
      importScripts("blob:https://localhost:8080/7d2ec0b7-08b8-412e-b453-2a8b4e81a47b");
      CesiumWorkers["transferTypedArrayTest"]();
    