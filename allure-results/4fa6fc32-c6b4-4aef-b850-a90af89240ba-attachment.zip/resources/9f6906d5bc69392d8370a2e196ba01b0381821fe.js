
      importScripts("blob:https://localhost:8080/8841e9dc-2713-4dda-b546-ba5507fc3b16");
      CesiumWorkers["transferTypedArrayTest"]();
    