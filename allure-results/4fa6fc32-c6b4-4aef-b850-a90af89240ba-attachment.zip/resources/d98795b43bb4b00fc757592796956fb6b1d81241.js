
      importScripts("blob:https://localhost:8080/f3ab86f1-64c1-40a9-90ba-b91d63e57fb4");
      CesiumWorkers["transferTypedArrayTest"]();
    