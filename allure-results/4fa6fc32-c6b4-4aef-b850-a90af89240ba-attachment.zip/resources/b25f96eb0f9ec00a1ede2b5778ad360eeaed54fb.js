
      importScripts("blob:https://localhost:8080/9b600d89-bb03-440b-bce3-f3bc82bd3024");
      CesiumWorkers["transferTypedArrayTest"]();
    