
      importScripts("blob:https://localhost:8080/0c96bfd2-4988-4cef-8fbd-bcc101149911");
      CesiumWorkers["createVerticesFromHeightmap"]();
    