
      importScripts("blob:https://localhost:8080/12eaa110-b847-4447-ad01-2cef3f282588");
      CesiumWorkers["createVerticesFromHeightmap"]();
    