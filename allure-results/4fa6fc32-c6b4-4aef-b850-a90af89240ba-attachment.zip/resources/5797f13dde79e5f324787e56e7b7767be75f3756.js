
      importScripts("blob:https://localhost:8080/c5183610-5547-4b37-a859-a6340ad36505");
      CesiumWorkers["createVerticesFromHeightmap"]();
    