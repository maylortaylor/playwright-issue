
      importScripts("blob:https://localhost:8080/bae3d83f-472d-4f9c-9459-c46d80a9e4f7");
      CesiumWorkers["transferTypedArrayTest"]();
    