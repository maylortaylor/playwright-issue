
      importScripts("blob:https://localhost:8080/b2669517-aaec-4891-801f-f5991da86732");
      CesiumWorkers["transferTypedArrayTest"]();
    