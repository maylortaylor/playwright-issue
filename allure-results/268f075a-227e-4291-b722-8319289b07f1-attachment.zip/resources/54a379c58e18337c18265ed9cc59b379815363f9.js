
      importScripts("blob:https://localhost:8080/7bd7607f-0a69-413b-abf1-2f1ed0c13f11");
      CesiumWorkers["createVerticesFromHeightmap"]();
    