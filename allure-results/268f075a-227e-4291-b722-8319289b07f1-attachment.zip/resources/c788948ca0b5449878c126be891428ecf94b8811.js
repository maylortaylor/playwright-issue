
      importScripts("blob:https://localhost:8080/88a00037-4df8-478a-a04d-8a5c7def7538");
      CesiumWorkers["createVerticesFromHeightmap"]();
    