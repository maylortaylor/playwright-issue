
      importScripts("blob:https://localhost:8080/cd323fa6-350d-4996-9e9c-42ca49fd6c36");
      CesiumWorkers["transferTypedArrayTest"]();
    