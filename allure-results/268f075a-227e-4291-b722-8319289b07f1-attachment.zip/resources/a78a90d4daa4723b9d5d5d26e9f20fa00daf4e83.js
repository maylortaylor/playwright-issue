
      importScripts("blob:https://localhost:8080/23cbae4e-4119-4c3f-8d8f-21a4940e2dfc");
      CesiumWorkers["createVerticesFromHeightmap"]();
    