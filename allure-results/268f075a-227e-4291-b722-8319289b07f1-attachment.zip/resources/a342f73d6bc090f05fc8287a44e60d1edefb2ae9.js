
      importScripts("blob:https://localhost:8080/5ac27881-b8ed-44c8-a934-ffc3a132b049");
      CesiumWorkers["createVerticesFromHeightmap"]();
    