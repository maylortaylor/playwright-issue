
      importScripts("blob:https://localhost:8080/53d0b1a7-a916-4f0c-ad1a-6a01fd3f5b70");
      CesiumWorkers["transferTypedArrayTest"]();
    