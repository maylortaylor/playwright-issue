
      importScripts("blob:https://localhost:8080/d003020f-387f-48ea-bed5-a76d79dab8ef");
      CesiumWorkers["createVerticesFromHeightmap"]();
    