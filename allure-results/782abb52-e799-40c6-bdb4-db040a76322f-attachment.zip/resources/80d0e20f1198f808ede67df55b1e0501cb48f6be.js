
      importScripts("blob:https://localhost:8080/464d2fa9-09d3-45fa-b9d1-16a7565d0356");
      CesiumWorkers["createVerticesFromHeightmap"]();
    