
      importScripts("blob:https://localhost:8080/d3b9d7dd-1b17-4ab4-9be1-3742ee44561d");
      CesiumWorkers["transferTypedArrayTest"]();
    