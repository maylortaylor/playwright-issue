
      importScripts("blob:https://localhost:8080/8104a256-f554-4d55-938d-51f09a11f751");
      CesiumWorkers["transferTypedArrayTest"]();
    