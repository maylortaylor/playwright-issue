
      importScripts("blob:https://localhost:8080/60e219b5-414c-4d01-b421-e463537cdaed");
      CesiumWorkers["createVerticesFromHeightmap"]();
    