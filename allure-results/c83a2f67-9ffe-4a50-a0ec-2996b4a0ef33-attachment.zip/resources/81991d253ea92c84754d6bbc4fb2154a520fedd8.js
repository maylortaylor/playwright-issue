
      importScripts("blob:https://localhost:8080/9ff14596-c901-46b9-87c8-0b0d71a73f9a");
      CesiumWorkers["transferTypedArrayTest"]();
    