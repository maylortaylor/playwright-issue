
      importScripts("blob:https://localhost:8080/33f43a8c-cb37-41d4-9902-5fbf7f5d5a91");
      CesiumWorkers["transferTypedArrayTest"]();
    