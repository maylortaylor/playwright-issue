
      importScripts("blob:https://localhost:8080/42bf4188-dbcf-4056-84d3-6ec649e2e911");
      CesiumWorkers["createVerticesFromHeightmap"]();
    