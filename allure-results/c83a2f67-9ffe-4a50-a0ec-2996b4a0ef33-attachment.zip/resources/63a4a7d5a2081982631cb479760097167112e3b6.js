
      importScripts("blob:https://localhost:8080/67966e3d-42ef-478b-a2cd-3513eeb90c0d");
      CesiumWorkers["createVerticesFromHeightmap"]();
    