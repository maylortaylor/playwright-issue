
      importScripts("blob:https://localhost:8080/c31f4c3d-692f-443a-a06d-d1e6f82a6453");
      CesiumWorkers["createVerticesFromHeightmap"]();
    