
      importScripts("blob:https://localhost:8080/fcdcefcf-6dbb-4155-bded-0145a0164692");
      CesiumWorkers["transferTypedArrayTest"]();
    