
      importScripts("blob:https://localhost:8080/d2efa9f0-7995-4d35-b3bd-dbe2b5b606ed");
      CesiumWorkers["createVerticesFromHeightmap"]();
    