
      importScripts("blob:https://localhost:8080/f953ad61-d4f7-491a-bfe5-ed1c9c715a05");
      CesiumWorkers["transferTypedArrayTest"]();
    