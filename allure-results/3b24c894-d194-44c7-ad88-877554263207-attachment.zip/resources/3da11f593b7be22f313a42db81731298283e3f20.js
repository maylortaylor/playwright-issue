/*! For license information please see chunk-P44SUSQU.js.LICENSE.txt */
function u(e,t){return e??t}u.EMPTY_OBJECT=Object.freeze({});var t=u;export{t as a};