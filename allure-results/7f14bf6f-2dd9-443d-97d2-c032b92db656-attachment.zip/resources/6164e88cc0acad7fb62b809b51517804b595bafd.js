
      importScripts("blob:https://localhost:8080/203a00f0-f8f9-4f53-9df6-6d9f74c27c73");
      CesiumWorkers["createVerticesFromHeightmap"]();
    