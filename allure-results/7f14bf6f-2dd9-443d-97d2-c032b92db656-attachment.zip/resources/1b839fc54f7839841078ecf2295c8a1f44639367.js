
      importScripts("blob:https://localhost:8080/ebd839e9-62ef-466a-b48e-c048a62c7c15");
      CesiumWorkers["transferTypedArrayTest"]();
    