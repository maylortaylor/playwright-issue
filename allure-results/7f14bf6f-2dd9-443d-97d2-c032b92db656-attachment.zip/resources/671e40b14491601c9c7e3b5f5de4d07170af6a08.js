
      importScripts("blob:https://localhost:8080/75fe7e76-4ab1-4965-b105-2650ca0d274a");
      CesiumWorkers["createVerticesFromHeightmap"]();
    