
      importScripts("blob:https://localhost:8080/49b25816-3e52-4445-860f-a1df3415f09a");
      CesiumWorkers["transferTypedArrayTest"]();
    