
      importScripts("blob:https://localhost:8080/03f6fa52-f870-4f0d-a09a-2a3e610bdfa4");
      CesiumWorkers["createVerticesFromHeightmap"]();
    