
      importScripts("blob:https://localhost:8080/7cf6c103-f098-49c4-b31a-d5219484f751");
      CesiumWorkers["transferTypedArrayTest"]();
    