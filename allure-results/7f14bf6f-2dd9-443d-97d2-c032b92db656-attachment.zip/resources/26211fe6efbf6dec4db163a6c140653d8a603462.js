
      importScripts("blob:https://localhost:8080/107174ff-1399-476e-b79f-82e5d8275bcb");
      CesiumWorkers["createVerticesFromHeightmap"]();
    