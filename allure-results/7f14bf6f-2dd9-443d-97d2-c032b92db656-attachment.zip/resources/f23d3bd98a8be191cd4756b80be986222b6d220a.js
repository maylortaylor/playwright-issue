
      importScripts("blob:https://localhost:8080/afd4ec13-8603-4e27-a945-1853b1961e92");
      CesiumWorkers["transferTypedArrayTest"]();
    