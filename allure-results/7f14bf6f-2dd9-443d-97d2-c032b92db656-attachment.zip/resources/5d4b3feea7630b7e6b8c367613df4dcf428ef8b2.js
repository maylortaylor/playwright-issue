
      importScripts("blob:https://localhost:8080/3165eca9-bf85-41ed-aa91-0b5d0c06bf3e");
      CesiumWorkers["createVerticesFromHeightmap"]();
    