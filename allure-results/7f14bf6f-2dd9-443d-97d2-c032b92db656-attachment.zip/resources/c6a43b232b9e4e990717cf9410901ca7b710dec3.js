
      importScripts("blob:https://localhost:8080/f9ea4856-4968-4847-9f42-ad8db74f4011");
      CesiumWorkers["transferTypedArrayTest"]();
    