
      importScripts("blob:https://localhost:8080/16d4c402-c80d-4601-a64b-571d65c53a8e");
      CesiumWorkers["createVerticesFromHeightmap"]();
    