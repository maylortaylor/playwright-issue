
      importScripts("blob:https://localhost:8080/553576bc-e538-423d-8ac7-6d37d84e310f");
      CesiumWorkers["transferTypedArrayTest"]();
    