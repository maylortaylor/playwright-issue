
      importScripts("blob:https://localhost:8080/2783a4be-738a-4aa4-abc3-be98961d6be2");
      CesiumWorkers["createVerticesFromHeightmap"]();
    