
      importScripts("blob:https://localhost:8080/d333e862-ee32-429f-a15c-6406e4af320b");
      CesiumWorkers["createVerticesFromHeightmap"]();
    