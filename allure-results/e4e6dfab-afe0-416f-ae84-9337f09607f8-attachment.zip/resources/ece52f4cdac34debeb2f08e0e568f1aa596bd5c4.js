
      importScripts("blob:https://localhost:8080/f69aa076-84f2-46f6-8f2a-99f9a63b221e");
      CesiumWorkers["transferTypedArrayTest"]();
    