
      importScripts("blob:https://localhost:8080/945559d1-1bb5-4128-8b2d-c0dad4cd6d7f");
      CesiumWorkers["createVerticesFromHeightmap"]();
    