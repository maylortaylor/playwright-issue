
      importScripts("blob:https://localhost:8080/8daf8b9f-d266-432c-bffe-d03bcf6e78e1");
      CesiumWorkers["transferTypedArrayTest"]();
    