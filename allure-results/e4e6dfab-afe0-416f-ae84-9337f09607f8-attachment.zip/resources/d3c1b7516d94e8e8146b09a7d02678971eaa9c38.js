
      importScripts("blob:https://localhost:8080/e740d156-db4d-49a6-aa7b-e65268b2a55b");
      CesiumWorkers["transferTypedArrayTest"]();
    