
      importScripts("blob:https://localhost:8080/264be272-7efd-4040-ab87-4d0ec22ef73a");
      CesiumWorkers["createVerticesFromHeightmap"]();
    