
      importScripts("blob:https://localhost:8080/c1eb87f8-a4f6-43f3-a2e5-342689824e15");
      CesiumWorkers["createVerticesFromHeightmap"]();
    