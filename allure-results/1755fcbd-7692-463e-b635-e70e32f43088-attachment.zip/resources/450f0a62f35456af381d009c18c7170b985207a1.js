
      importScripts("blob:https://localhost:8080/a5087725-0557-46a2-8b33-16422fbe940e");
      CesiumWorkers["transferTypedArrayTest"]();
    