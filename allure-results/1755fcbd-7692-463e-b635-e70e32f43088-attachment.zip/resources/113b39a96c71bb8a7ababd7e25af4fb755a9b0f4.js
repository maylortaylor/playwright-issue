
      importScripts("blob:https://localhost:8080/44eed130-d0aa-4b72-a2e4-a972edee0069");
      CesiumWorkers["transferTypedArrayTest"]();
    