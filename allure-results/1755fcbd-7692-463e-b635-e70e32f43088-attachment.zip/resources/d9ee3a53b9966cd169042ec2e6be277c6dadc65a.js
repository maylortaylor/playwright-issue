
      importScripts("blob:https://localhost:8080/f09d4239-feeb-40c0-a1c9-77a844100dde");
      CesiumWorkers["transferTypedArrayTest"]();
    