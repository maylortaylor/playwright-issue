
      importScripts("blob:https://localhost:8080/4adeb5ee-e8fc-425f-983c-2661b5c3e7a7");
      CesiumWorkers["createVerticesFromHeightmap"]();
    