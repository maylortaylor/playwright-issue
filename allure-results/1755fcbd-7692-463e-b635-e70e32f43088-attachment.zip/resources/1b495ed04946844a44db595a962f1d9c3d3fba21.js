
      importScripts("blob:https://localhost:8080/dd623cee-0eef-468b-9b68-45601afee5d3");
      CesiumWorkers["createVerticesFromHeightmap"]();
    