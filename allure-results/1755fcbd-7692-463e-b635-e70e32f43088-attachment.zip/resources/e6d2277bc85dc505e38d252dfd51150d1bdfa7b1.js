
      importScripts("blob:https://localhost:8080/ec350426-6c55-475d-a528-cb88824c57ff");
      CesiumWorkers["transferTypedArrayTest"]();
    