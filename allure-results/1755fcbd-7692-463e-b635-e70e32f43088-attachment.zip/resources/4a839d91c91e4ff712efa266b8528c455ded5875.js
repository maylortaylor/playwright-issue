
      importScripts("blob:https://localhost:8080/e8e95e51-019d-4198-8324-f2aecd9abb1d");
      CesiumWorkers["createVerticesFromHeightmap"]();
    