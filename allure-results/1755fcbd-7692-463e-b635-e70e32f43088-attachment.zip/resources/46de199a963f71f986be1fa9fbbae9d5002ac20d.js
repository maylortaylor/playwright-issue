
      importScripts("blob:https://localhost:8080/9fff95f5-1728-4e23-a8b7-f0c4c38312bd");
      CesiumWorkers["createVerticesFromHeightmap"]();
    