
      importScripts("blob:https://localhost:8080/8b7f666f-70af-42e6-8361-e1ddda0feded");
      CesiumWorkers["createVerticesFromHeightmap"]();
    