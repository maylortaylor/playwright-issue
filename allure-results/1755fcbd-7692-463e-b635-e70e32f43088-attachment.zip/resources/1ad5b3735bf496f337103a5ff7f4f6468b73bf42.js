
      importScripts("blob:https://localhost:8080/81897db9-44f4-48e3-8494-422cd4809929");
      CesiumWorkers["createVerticesFromHeightmap"]();
    