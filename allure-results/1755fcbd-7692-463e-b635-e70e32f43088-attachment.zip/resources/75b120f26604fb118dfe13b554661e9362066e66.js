
      importScripts("blob:https://localhost:8080/80bb7648-3f39-4cea-b0e2-3680603e2982");
      CesiumWorkers["transferTypedArrayTest"]();
    