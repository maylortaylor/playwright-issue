
      importScripts("blob:https://localhost:8080/2c557dde-b422-4e50-8d18-0328a6b7e3c6");
      CesiumWorkers["transferTypedArrayTest"]();
    