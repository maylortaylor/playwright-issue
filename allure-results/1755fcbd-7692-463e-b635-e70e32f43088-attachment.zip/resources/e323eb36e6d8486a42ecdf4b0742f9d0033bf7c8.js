
      importScripts("blob:https://localhost:8080/742a8f64-4112-4d51-927d-f9351eacf4f5");
      CesiumWorkers["transferTypedArrayTest"]();
    