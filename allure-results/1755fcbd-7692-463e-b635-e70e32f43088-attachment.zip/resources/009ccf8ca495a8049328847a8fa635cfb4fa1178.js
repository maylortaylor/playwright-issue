
      importScripts("blob:https://localhost:8080/5482d427-2d5a-41a9-aa02-40dd35fdbee5");
      CesiumWorkers["transferTypedArrayTest"]();
    