
      importScripts("blob:https://localhost:8080/9fa9ebb1-ac26-4dca-b3fe-c5c0e8fcd8a9");
      CesiumWorkers["transferTypedArrayTest"]();
    