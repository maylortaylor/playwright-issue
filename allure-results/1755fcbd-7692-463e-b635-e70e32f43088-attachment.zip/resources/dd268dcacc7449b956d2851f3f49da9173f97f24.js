
      importScripts("blob:https://localhost:8080/ef8ccb56-ff50-481d-8d40-cccc10ad8d0f");
      CesiumWorkers["createVerticesFromHeightmap"]();
    