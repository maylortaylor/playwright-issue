
      importScripts("blob:https://localhost:8080/f30788a5-6c62-47f9-b143-a274ab74cbad");
      CesiumWorkers["createVerticesFromHeightmap"]();
    