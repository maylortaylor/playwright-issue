
      importScripts("blob:https://localhost:8080/0d30fdb0-f4d4-4552-b0e3-42eaed0f643b");
      CesiumWorkers["transferTypedArrayTest"]();
    