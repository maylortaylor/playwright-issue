
      importScripts("blob:https://localhost:8080/07dba115-092c-4db9-9c13-285a70e505b0");
      CesiumWorkers["transferTypedArrayTest"]();
    