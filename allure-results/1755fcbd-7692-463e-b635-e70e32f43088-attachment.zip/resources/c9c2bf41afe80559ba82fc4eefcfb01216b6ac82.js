
      importScripts("blob:https://localhost:8080/f2056b6e-af50-441b-b83f-a1e5e7783fe6");
      CesiumWorkers["createVerticesFromHeightmap"]();
    