
      importScripts("blob:https://localhost:8080/d5f53079-239b-4d2f-9b23-c227e3dccb97");
      CesiumWorkers["createVerticesFromHeightmap"]();
    