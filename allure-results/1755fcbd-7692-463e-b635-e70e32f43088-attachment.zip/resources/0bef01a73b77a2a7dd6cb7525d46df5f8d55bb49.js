
      importScripts("blob:https://localhost:8080/07b2ab23-9e5c-40a0-b2b6-735644d8763f");
      CesiumWorkers["createVerticesFromHeightmap"]();
    