
      importScripts("blob:https://localhost:8080/5de84b65-2d42-4cd9-8360-f11da339707f");
      CesiumWorkers["transferTypedArrayTest"]();
    